from django.shortcuts import render

from django.utils.crypto import get_random_string

def Random_Word(request):
    if 'count' not in request.session:
        request.session['count'] = 0
        request.session['count'] += 1
        request.session['word'] = get_random_string(14)
    return render(request, 'index.html')

def reset(request):
    request.session.flush()
    return redirect('/Random_Word')

